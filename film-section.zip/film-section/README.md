# Film Section — theswaymvar

Self-contained implementation of the `/film` page and `/films/$slug` detail
route, built against TanStack Router + Tailwind + Framer Motion + GSAP, in
the same visual language as your existing `film.tsx` (`shell`, `font-display`,
`label-xs`, `text-bronze`, `bg-charcoal`, `Reveal`/`RevealImage`,
`SectionHeading`, `WhatsAppButton`).

## Install

```bash
npm install framer-motion gsap lucide-react
```

`@tanstack/react-router` and Tailwind are assumed already present (your
pasted `film.tsx` already imports from `@tanstack/react-router`).

## Wiring it in

1. **Drop `src/` into your project**, matching the paths below to your own
   `tsconfig`/`vite` `@` alias.
2. **If you already have real versions of these five files, delete mine and
   keep yours** — every film component only depends on their prop shapes,
   which match what your `film.tsx` already calls:
   - `src/components/site/Reveal.tsx`
   - `src/components/site/RevealImage.tsx`
   - `src/components/site/SectionHeading.tsx`
   - `src/components/site/CTA.tsx` (`WhatsAppButton`)
   - `src/data/images.ts`
3. **If you don't have those yet**, keep mine and import
   `src/styles/film-tokens.css` once in your root layout — it defines
   `--charcoal` / `--bronze` / `--background` etc. as CSS variables and
   plain-CSS fallbacks for `.shell`, `.label-xs`, `.font-display`, `.grain`,
   `.story-link`, `.section-y-lg` so the page renders correctly even before
   you merge these into your real Tailwind config.
4. **Set your real WhatsApp number** in `src/components/site/CTA.tsx`
   (`WHATSAPP_NUMBER`).
5. **Replace placeholder assets.** `src/data/images.ts` is the only file
   that lists poster/video paths — every path currently points at a file
   that doesn't exist yet, and `video` fields are empty strings. Every
   player component treats a missing poster/video as a graceful "Film
   coming soon" state rather than a broken UI (spec §45), so the page is
   safe to ship before assets land — just update the paths in
   `images.ts` as real files arrive. **No stock or placeholder footage
   has been invented** — see spec §26.
6. **Fill in real film data** in `src/data/films.ts` — it's the single
   source of truth powering Featured Film, Collection, Stories, and
   Destination Films. Keep exactly one `featured: true`, one film with
   `chapters`, and mark `destination: true` on whichever films belong in
   the Destination Films section (independent of `category`).

## Architecture

```
src/
  styles/film-tokens.css        design tokens + plain-CSS fallbacks
  types/film.ts                 Film / FilmChapter shape, FILM_CATEGORIES
  data/
    images.ts                   ONLY place listing poster/video paths
    films.ts                    single source of truth for all film data
  hooks/
    use-reduced-motion.ts       live prefers-reduced-motion
    use-in-view.ts              IntersectionObserver, powers lazy loading
  lib/gsap.ts                   registers ScrollTrigger exactly once
  components/
    site/                       Reveal, RevealImage, SectionHeading, CTA
    film/
      LazyVideo.tsx              poster-first hover-preview media (cards)
      FilmPlayer.tsx             full playback controls (chapters/showreel/detail)
      FilmHero.tsx                §04 — quiet intro, no image, GSAP text reveal
      FeaturedFilm.tsx            §05 — one dominant film, links to detail route
      FilmFilter.tsx              §08–09, §33 — functional, accessible filter
      FilmCard.tsx                §11–12 — collection grid card
      FilmCollection.tsx          §07, §10, §13 — filter state + grid + load more
      FilmChapter.tsx             §15 — one story chapter row
      FilmStories.tsx             §14–17 — alternating chapters, GSAP scroll line
      CinematicShowreel.tsx       §18–20 — single full-width video
      DestinationFilm.tsx         §22–23 — one destination row, GSAP parallax
      DestinationFilms.tsx        §21, §24 — wraps DestinationFilm, reuses detail route
  routes/
    film.tsx                     assembles all six sections in order
    films.$slug.tsx               dedicated detail route (theater player)
```

## Decisions made on your behalf

- **Detail route over modal.** `/films/$slug` — shareable URLs, working
  back button, real SEO per film, and it's the spec's stated preference
  (§05). `FilmPlayer`'s `theater` variant is a plain component, so it's a
  five-minute job to wrap it in a modal later if you change your mind —
  nothing about the data layer or other sections depends on the routing
  choice.
- **GSAP is used exactly twice**, deliberately, so it never competes with
  Framer Motion's scroll-reveals: a clip-path title reveal in the Hero, a
  scroll-scrubbed progress line down Film Stories, and a subtle parallax
  on Destination Film posters. Everything else (fades, filter underline,
  card hover, grid re-flow) is Framer Motion. All GSAP tweens are killed
  on unmount and skipped entirely under `prefers-reduced-motion`.
- **Chapters and the Showreel autoplay only when muted, in view, and not
  reduced-motion** — never with sound, per spec §17/§20/§37.
- **Missing metadata is omitted, not labelled-empty** — e.g. no `couple`
  → no line rendered, never a bare "Couple:" (spec §45).

## Not done for you

- Real poster/video assets — see step 5 above.
- Your real WhatsApp number.
- Merging `film-tokens.css`'s colors/fonts into your actual Tailwind
  config, if you'd rather do that than keep the CSS-variable fallback.
- Wiring `/films/$slug` into your router's route tree file, if your
  TanStack Router setup uses a manually-maintained route tree rather than
  the file-based generator.
