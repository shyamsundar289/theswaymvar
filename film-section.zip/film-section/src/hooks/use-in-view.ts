import { useEffect, useRef, useState, type RefObject } from "react";

interface UseInViewOptions {
  /** Grow/shrink the trigger area — a positive rootMargin fires earlier */
  rootMargin?: string;
  /** Fraction of the element that must be visible to count as "in view" */
  threshold?: number;
  /** Once true, stop observing (good for lazy-video reveal, bad for autoplay-on-scroll) */
  once?: boolean;
}

/**
 * Minimal, dependency-free viewport-visibility hook.
 * Powers lazy video loading (Film Collection, Destination Films) and
 * viewport-aware muted-autoplay (Showreel).
 */
export function useInView<T extends HTMLElement>(
  options: UseInViewOptions = {},
): [RefObject<T | null>, boolean] {
  const { rootMargin = "200px 0px", threshold = 0.15, once = false } = options;
  const ref = useRef<T | null>(null);
  const [inView, setInView] = useState(false);

  useEffect(() => {
    const node = ref.current;
    if (!node || typeof IntersectionObserver === "undefined") {
      // Environments without IO support (very old browsers) — degrade to visible
      setInView(true);
      return;
    }

    const observer = new IntersectionObserver(
      ([entry]) => {
        setInView(entry.isIntersecting);
        if (entry.isIntersecting && once) observer.disconnect();
      },
      { rootMargin, threshold },
    );

    observer.observe(node);
    return () => observer.disconnect();
  }, [rootMargin, threshold, once]);

  return [ref, inView];
}
