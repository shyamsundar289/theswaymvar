import { useEffect, useRef } from "react";
import type { Film } from "@/types/film";
import { FilmChapter } from "./FilmChapter";
import { Reveal } from "@/components/site/Reveal";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

interface FilmStoriesProps {
  film: Film;
}

/**
 * Tell a story (spec §38). Not a grid — one wedding, broken into chapters,
 * alternating left/right for rhythm (spec §14–§17). The vertical line
 * tracking scroll progress through the chapters is this section's single
 * GSAP signature moment; everything else stays as quiet Framer Motion
 * fades so the two motion libraries don't compete for attention.
 */
export function FilmStories({ film }: FilmStoriesProps) {
  const sectionRef = useRef<HTMLDivElement>(null);
  const trackRef = useRef<HTMLDivElement>(null);
  const fillRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;
    const section = sectionRef.current;
    const fill = fillRef.current;
    if (!section || !fill) return;

    const trigger = ScrollTrigger.create({
      trigger: section,
      start: "top 20%",
      end: "bottom 80%",
      scrub: 0.6,
      onUpdate: (self) => {
        gsap.set(fill, { scaleY: self.progress });
      },
    });

    // Guards against a stuck fill after fast/jump scrolling (spec §46)
    return () => {
      trigger.kill();
    };
  }, [prefersReducedMotion]);

  if (!film.chapters || film.chapters.length === 0) return null;

  return (
    <section ref={sectionRef} className="shell section-y-lg">
      <Reveal>
        <p className="label-xs text-bronze">Film stories</p>
        <h2 className="font-display mt-4 text-4xl leading-[0.95] md:text-6xl">
          {film.title}
        </h2>
        <p className="mt-4 max-w-lg text-sm leading-relaxed text-muted-foreground md:text-base">
          One wedding, told in full — six chapters, cut from three days in {film.location}.
        </p>
      </Reveal>

      <div className="relative mt-14 md:pl-10">
        {/* Scroll-progress track — desktop only, decorative (aria-hidden) */}
        <div
          ref={trackRef}
          aria-hidden="true"
          className="absolute left-0 top-0 hidden h-full w-px bg-border md:block"
        >
          <div
            ref={fillRef}
            className="h-full w-full origin-top bg-bronze"
            style={{ transform: "scaleY(0)" }}
          />
        </div>

        <div className="divide-y divide-border/60">
          {film.chapters.map((chapter, index) => (
            <FilmChapter key={chapter.number} chapter={chapter} reverse={index % 2 === 1} />
          ))}
        </div>
      </div>
    </section>
  );
}
