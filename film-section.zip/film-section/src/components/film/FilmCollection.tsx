import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import type { Film, FilmCategory } from "@/types/film";
import { FilmFilter } from "./FilmFilter";
import { FilmCard } from "./FilmCard";
import { SectionHeading } from "@/components/site/SectionHeading";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

interface FilmCollectionProps {
  films: Film[];
}

const PAGE_SIZE = 6;

/**
 * Browse (spec §38). Single source of truth for filtering: `selectedCategory`
 * drives a derived `filteredFilms` list rather than four hardcoded grids
 * (spec §44). Pagination keeps large libraries from loading every video at
 * once (spec §13, §27).
 */
export function FilmCollection({ films }: FilmCollectionProps) {
  const [selectedCategory, setSelectedCategory] = useState<FilmCategory | "all">("all");
  const [visibleCount, setVisibleCount] = useState(PAGE_SIZE);
  const prefersReducedMotion = useReducedMotion();

  const filteredFilms = useMemo(() => {
    if (selectedCategory === "all") return films;
    return films.filter((film) => film.category === selectedCategory);
  }, [films, selectedCategory]);

  const visibleFilms = filteredFilms.slice(0, visibleCount);
  const hasMore = visibleCount < filteredFilms.length;

  function handleFilterChange(next: FilmCategory | "all") {
    setSelectedCategory(next);
    setVisibleCount(PAGE_SIZE); // reset pagination on filter change
  }

  return (
    <section className="border-y border-border/60">
      <div className="shell section-y-lg">
        <div className="flex flex-col gap-10 md:flex-row md:items-end md:justify-between">
          <SectionHeading eyebrow="Browse the archive" title="Film collection" />
          <FilmFilter value={selectedCategory} onChange={handleFilterChange} />
        </div>

        <div className="mt-14 grid grid-cols-1 gap-x-8 gap-y-14 md:grid-cols-2 md:gap-x-10 md:gap-y-16">
          <AnimatePresence mode="popLayout">
            {visibleFilms.map((film) => (
              <motion.div
                key={film.id}
                layout
                initial={{ opacity: 0, y: prefersReducedMotion ? 0 : 16 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0 }}
                transition={{ duration: prefersReducedMotion ? 0.15 : 0.45, ease: [0.16, 1, 0.3, 1] }}
              >
                <FilmCard film={film} />
              </motion.div>
            ))}
          </AnimatePresence>
        </div>

        {filteredFilms.length === 0 ? (
          <p className="mt-14 text-sm text-muted-foreground">
            No films in this category yet — check back soon.
          </p>
        ) : null}

        {hasMore ? (
          <div className="mt-16 flex justify-center">
            <button
              type="button"
              onClick={() => setVisibleCount((count) => count + PAGE_SIZE)}
              className="label-xs story-link inline-flex items-center gap-2 border border-border px-8 py-4 transition-colors hover:border-bronze hover:text-bronze"
            >
              Load more films
            </button>
          </div>
        ) : null}
      </div>
    </section>
  );
}
