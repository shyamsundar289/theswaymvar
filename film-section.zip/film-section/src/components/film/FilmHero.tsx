import { useEffect, useRef } from "react";
import { gsap } from "@/lib/gsap";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

/**
 * Film Hero — introduction only (spec §04).
 * Deliberately quiet: no image, no video, no CTA, no filter. The one
 * animated moment on this page-load is a clip-path reveal of "FILMS",
 * kept here so it doesn't compete with Featured Film immediately below.
 */
export function FilmHero() {
  const headingRef = useRef<HTMLHeadingElement>(null);
  const subRef = useRef<HTMLParagraphElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;
    const heading = headingRef.current;
    const sub = subRef.current;
    if (!heading || !sub) return;

    const timeline = gsap.timeline({ defaults: { ease: "expo.out" } });
    timeline
      .fromTo(
        heading,
        { clipPath: "inset(0 0 100% 0)", opacity: 0 },
        { clipPath: "inset(0 0 0% 0)", opacity: 1, duration: 1.1 },
      )
      .fromTo(sub, { opacity: 0, y: 8 }, { opacity: 1, y: 0, duration: 0.6 }, "-=0.3");

    return () => {
      timeline.kill();
    };
  }, [prefersReducedMotion]);

  return (
    <section className="flex h-[230px] items-center justify-center bg-background md:h-[280px] lg:h-[320px]">
      <div className="text-center">
        <h1
          ref={headingRef}
          className="font-display text-[15vw] leading-none tracking-tight sm:text-7xl md:text-8xl"
        >
          Films
        </h1>
        <p ref={subRef} className="label-xs mt-5 text-bronze">
          Cinematic wedding stories
        </p>
      </div>
    </section>
  );
}
