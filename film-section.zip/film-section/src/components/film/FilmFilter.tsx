import { motion } from "framer-motion";
import { FILM_CATEGORIES, type FilmCategory } from "@/types/film";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

interface FilmFilterProps {
  value: FilmCategory | "all";
  onChange: (value: FilmCategory | "all") => void;
}

/**
 * Spec §08–§09, §33: functional, minimal, no button-group styling.
 * A single shared underline slides between the active label using a
 * Framer Motion `layoutId`, rather than each button owning its own
 * transition — reads as one continuous indicator, not four buttons.
 */
export function FilmFilter({ value, onChange }: FilmFilterProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <div className="flex flex-col gap-4">
      <span className="label-xs text-muted-foreground">Select</span>

      <div
        role="group"
        aria-label="Filter films by category"
        className="flex flex-wrap items-center gap-x-8 gap-y-3"
      >
        {FILM_CATEGORIES.map((category) => {
          const active = category.value === value;
          return (
            <button
              key={category.value}
              type="button"
              aria-pressed={active}
              onClick={() => onChange(category.value)}
              className={`label-xs relative pb-2 transition-colors ${
                active ? "text-foreground" : "text-muted-foreground hover:text-foreground"
              }`}
            >
              {category.label}
              {active ? (
                <motion.span
                  layoutId="film-filter-underline"
                  className="absolute inset-x-0 -bottom-px h-px bg-bronze"
                  transition={{ duration: prefersReducedMotion ? 0 : 0.35, ease: [0.65, 0, 0.35, 1] }}
                />
              ) : null}
            </button>
          );
        })}
      </div>
    </div>
  );
}
