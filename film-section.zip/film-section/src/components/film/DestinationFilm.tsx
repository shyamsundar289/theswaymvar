import { useEffect, useRef } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowUpRight } from "lucide-react";
import type { Film } from "@/types/film";
import { LazyVideo } from "./LazyVideo";
import { Reveal } from "@/components/site/Reveal";
import { gsap, ScrollTrigger } from "@/lib/gsap";
import { useReducedMotion } from "@/hooks/use-reduced-motion";

interface DestinationFilmProps {
  film: Film;
  reverse?: boolean;
}

export function DestinationFilm({ film, reverse = false }: DestinationFilmProps) {
  const mediaRef = useRef<HTMLDivElement>(null);
  const prefersReducedMotion = useReducedMotion();

  useEffect(() => {
    if (prefersReducedMotion) return;
    const node = mediaRef.current;
    if (!node) return;

    const tween = gsap.fromTo(
      node,
      { yPercent: -6 },
      {
        yPercent: 6,
        ease: "none",
        scrollTrigger: {
          trigger: node,
          start: "top bottom",
          end: "bottom top",
          scrub: 0.8,
        },
      },
    );

    return () => {
      tween.scrollTrigger?.kill();
      tween.kill();
    };
  }, [prefersReducedMotion]);

  return (
    <Reveal>
      <div className="flex flex-col gap-8 py-10 md:flex-row md:items-center md:gap-14 md:py-16">
        <div className={`overflow-hidden md:w-[62%] ${reverse ? "md:order-2" : "md:order-1"}`}>
          <Link to="/films/$slug" params={{ slug: film.slug }} aria-label={`Watch ${film.title}`}>
            <div className="overflow-hidden">
              <div ref={mediaRef} className="scale-110">
                <LazyVideo
                  poster={film.poster}
                  video={film.video}
                  alt={`${film.title} — ${film.location}`}
                  hoverPreview
                  className="aspect-[4/3] w-full md:aspect-[16/10]"
                />
              </div>
            </div>
          </Link>
        </div>

        <div className={`md:w-[38%] ${reverse ? "md:order-1 md:text-right" : "md:order-2"}`}>
          <h3 className="font-display text-4xl leading-[0.95] md:text-6xl">{film.location}</h3>
          {film.region ? (
            <p className="label-xs mt-3 text-bronze">{film.region}</p>
          ) : null}
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground md:text-base">
            {film.title}
            {film.couple ? ` — ${film.couple}` : ""}
          </p>
          <Link
            to="/films/$slug"
            params={{ slug: film.slug }}
            className={`story-link label-xs mt-5 inline-flex items-center gap-2 ${
              reverse ? "md:justify-end" : ""
            }`}
          >
            Watch film
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </div>
    </Reveal>
  );
}
