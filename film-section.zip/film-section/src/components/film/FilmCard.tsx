import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Play } from "lucide-react";
import type { Film } from "@/types/film";
import { LazyVideo } from "./LazyVideo";

interface FilmCardProps {
  film: Film;
}

const CATEGORY_LABEL: Record<Film["category"], string> = {
  wedding: "Wedding",
  "pre-wedding": "Pre-Wedding",
  destination: "Destination",
};

export function FilmCard({ film }: FilmCardProps) {
  const metaLine = [film.location, film.year].filter(Boolean).join(" · ");

  return (
    <Link
      to="/films/$slug"
      params={{ slug: film.slug }}
      className="group block"
      aria-label={`Watch ${film.title}`}
    >
      <div className="relative overflow-hidden">
        <LazyVideo
          poster={film.poster}
          video={film.video}
          alt={`Still from ${film.title}`}
          hoverPreview
          className="aspect-[4/5] w-full transition-transform duration-700 ease-out group-hover:scale-[1.03] md:aspect-[3/4]"
        />

        <div className="absolute inset-0 bg-charcoal/0 transition-colors duration-500 group-hover:bg-charcoal/15" />

        <span className="absolute right-5 top-5 flex h-10 w-10 items-center justify-center rounded-full border border-background/60 text-background opacity-0 transition-opacity duration-300 group-hover:opacity-100">
          <Play className="ml-0.5 h-3.5 w-3.5" fill="currentColor" />
        </span>

        <span className="label-xs absolute left-5 top-5 text-background/80">
          {CATEGORY_LABEL[film.category]}
        </span>
      </div>

      <div className="mt-5">
        <h3 className="font-display text-2xl md:text-3xl">{film.title}</h3>
        {film.couple ? (
          <p className="mt-1 text-sm text-muted-foreground">{film.couple}</p>
        ) : null}
        <p className="label-xs mt-3 text-muted-foreground">
          {metaLine} · {film.duration}
        </p>

        <span className="story-link label-xs mt-4 inline-flex items-center gap-2 text-foreground">
          Watch film
          <ArrowUpRight className="h-3.5 w-3.5 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
        </span>
      </div>
    </Link>
  );
}
