import { Link } from "@tanstack/react-router";
import { ArrowUpRight, Play } from "lucide-react";
import { motion } from "framer-motion";
import type { Film } from "@/types/film";
import { LazyVideo } from "./LazyVideo";
import { Reveal } from "@/components/site/Reveal";
import { SectionHeading } from "@/components/site/SectionHeading";

interface FeaturedFilmProps {
  film: Film;
}

/**
 * Immerse (spec §38). One primary film, large media, metadata underneath.
 * The whole block links to the dedicated detail route — clicking anywhere
 * on the poster or "Watch film" opens the same premium viewing experience
 * as every other entry point (spec §05, §06).
 */
export function FeaturedFilm({ film }: FeaturedFilmProps) {
  const metaLine = [film.location, film.region ? film.region.split(" · ")[0] : null, film.year]
    .filter(Boolean)
    .join(" · ");

  return (
    <section className="shell section-y-lg">
      <SectionHeading eyebrow="Featured film" title="Watch the day unfold." />

      <Reveal className="mt-14" delay={0.1}>
        <Link
          to="/films/$slug"
          params={{ slug: film.slug }}
          className="group mx-auto block w-full md:w-[88%]"
          aria-label={`Watch ${film.title}`}
        >
          <LazyVideo
            poster={film.poster}
            video={film.video}
            alt={`Still from ${film.title}`}
            hoverPreview
            className="aspect-video w-full transition-transform duration-1000 group-hover:scale-[1.015]"
          />

          <div className="relative -mt-24 flex items-end justify-between px-6 pb-6 text-background md:-mt-28 md:px-10 md:pb-10">
            <div className="pointer-events-none absolute inset-x-0 bottom-0 -z-10 h-40 bg-gradient-to-t from-charcoal/85 to-transparent" />

            <div>
              <p className="label-xs text-bronze">{film.category === "wedding" ? "Wedding film" : film.category}</p>
              <h3 className="font-display mt-2 text-3xl md:text-5xl">{film.title}</h3>
              {film.couple ? (
                <p className="mt-1 text-sm text-background/75 md:text-base">{film.couple}</p>
              ) : null}
              <p className="label-xs mt-3 text-background/60">
                {metaLine} · {film.duration}
              </p>
            </div>

            <motion.span
              whileHover={{ scale: 1.08 }}
              whileTap={{ scale: 0.95 }}
              className="hidden h-16 w-16 shrink-0 items-center justify-center rounded-full border border-background/70 md:flex"
            >
              <Play className="ml-0.5 h-5 w-5" fill="currentColor" />
            </motion.span>
          </div>
        </Link>

        <div className="mx-auto mt-6 flex w-full flex-col gap-4 md:w-[88%] md:flex-row md:items-end md:justify-between">
          <p className="max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
            {film.description}
          </p>
          <Link
            to="/films/$slug"
            params={{ slug: film.slug }}
            className="story-link label-xs inline-flex shrink-0 items-center gap-2"
          >
            Watch film
            <ArrowUpRight className="h-3.5 w-3.5" />
          </Link>
        </div>
      </Reveal>
    </section>
  );
}
