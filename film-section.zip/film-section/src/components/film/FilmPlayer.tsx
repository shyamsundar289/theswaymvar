import { useEffect, useRef, useState } from "react";
import { motion } from "framer-motion";
import { Maximize, Pause, Play, Volume2, VolumeX } from "lucide-react";
import { useInView } from "@/hooks/use-in-view";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { isMissingAsset } from "@/types/film";

interface FilmPlayerProps {
  poster: string;
  video?: string;
  title: string;
  className?: string;
  /**
   * 'theater' — the detail route's primary player: larger controls, starts
   * paused, no ambient autoplay.
   * 'inline' — Film Stories chapters / Showreel: smaller control bar, can
   * opt into a muted viewport-autoplay preview via `ambientAutoplay`.
   */
  variant?: "theater" | "inline";
  /** Muted, looped preview while in view and untouched by the user (Showreel only) */
  ambientAutoplay?: boolean;
}

function formatTime(seconds: number): string {
  if (!Number.isFinite(seconds)) return "0:00";
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60)
    .toString()
    .padStart(2, "0");
  return `${m}:${s}`;
}

export function FilmPlayer({
  poster,
  video,
  title,
  className,
  variant = "inline",
  ambientAutoplay = false,
}: FilmPlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [wrapperRef, inView] = useInView<HTMLDivElement>({ rootMargin: "-10% 0px" });
  const prefersReducedMotion = useReducedMotion();

  const hasVideo = !isMissingAsset(video);
  const [started, setStarted] = useState(false); // has the user (or ambient autoplay) initiated playback
  const [playing, setPlaying] = useState(false);
  const [muted, setMuted] = useState(true);
  const [progress, setProgress] = useState(0); // 0–1
  const [duration, setDuration] = useState(0);
  const [current, setCurrent] = useState(0);
  const [videoFailed, setVideoFailed] = useState(false);

  // Ambient autoplay: only for the showreel, only muted, only while in view,
  // only if the user hasn't already taken control, never against reduced motion.
  useEffect(() => {
    if (!ambientAutoplay || !hasVideo || prefersReducedMotion) return;
    const el = videoRef.current;
    if (!el) return;

    if (inView) {
      setStarted(true);
      el.play()
        .then(() => setPlaying(true))
        .catch(() => {
          /* browser blocked autoplay — poster remains, user can press play manually */
        });
    } else {
      el.pause();
      setPlaying(false);
    }
  }, [inView, ambientAutoplay, hasVideo, prefersReducedMotion]);

  function togglePlay() {
    const el = videoRef.current;
    if (!el || !hasVideo) return;
    setStarted(true);
    if (el.paused) {
      el.play()
        .then(() => setPlaying(true))
        .catch(() => setVideoFailed(true));
    } else {
      el.pause();
      setPlaying(false);
    }
  }

  function toggleMute() {
    const el = videoRef.current;
    if (!el) return;
    el.muted = !el.muted;
    setMuted(el.muted);
  }

  function handleScrub(event: React.ChangeEvent<HTMLInputElement>) {
    const el = videoRef.current;
    if (!el || !duration) return;
    const fraction = Number(event.target.value);
    el.currentTime = fraction * duration;
    setProgress(fraction);
  }

  function toggleFullscreen() {
    const node = containerRef.current;
    if (!node) return;
    if (document.fullscreenElement) {
      document.exitFullscreen().catch(() => {});
    } else {
      node.requestFullscreen?.().catch(() => {});
    }
  }

  function handleTimeUpdate() {
    const el = videoRef.current;
    if (!el || !el.duration) return;
    setCurrent(el.currentTime);
    setProgress(el.currentTime / el.duration);
  }

  function handleLoadedMetadata() {
    const el = videoRef.current;
    if (el) setDuration(el.duration);
  }

  const showFallback = !hasVideo || videoFailed;

  return (
    <div
      ref={(node) => {
        containerRef.current = node;
        wrapperRef.current = node;
      }}
      className={`group relative overflow-hidden bg-charcoal ${className ?? ""}`}
    >
      {/* Poster layer — always mounted underneath so a failed/missing video never blanks the frame */}
      {isMissingAsset(poster) ? (
        <div className="flex aspect-video w-full items-center justify-center bg-gradient-to-br from-charcoal to-[#231d18] text-background/25">
          <span className="label-xs">theswaymvar</span>
        </div>
      ) : (
        <img
          src={poster}
          alt={`${title} — poster frame`}
          className={`aspect-video w-full object-cover transition-opacity duration-700 ${
            started && playing && !showFallback ? "opacity-0" : "opacity-100"
          }`}
        />
      )}

      {hasVideo && !videoFailed ? (
        <video
          ref={videoRef}
          src={started ? video : undefined}
          preload={variant === "theater" ? "metadata" : "none"}
          muted={muted}
          playsInline
          loop={ambientAutoplay}
          onTimeUpdate={handleTimeUpdate}
          onLoadedMetadata={handleLoadedMetadata}
          onEnded={() => setPlaying(false)}
          onError={() => setVideoFailed(true)}
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${
            started ? "opacity-100" : "opacity-0"
          }`}
        />
      ) : null}

      {/* Dark scrim, present until playback starts */}
      <div
        className={`absolute inset-0 bg-charcoal/25 transition-opacity duration-500 ${
          started && playing ? "opacity-0 group-hover:opacity-100" : "opacity-100"
        }`}
      />

      {showFallback ? (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 text-background">
          <span className="label-xs text-background/70">Film coming soon</span>
          <span className="font-display text-xl">{title}</span>
        </div>
      ) : (
        <>
          {/* Center play control — shown until first play */}
          {!started || !playing ? (
            <button
              type="button"
              onClick={togglePlay}
              aria-label={playing ? `Pause ${title}` : `Play ${title}`}
              className="absolute inset-0 flex items-center justify-center"
            >
              <motion.span
                initial={false}
                whileHover={prefersReducedMotion ? undefined : { scale: 1.08 }}
                whileTap={{ scale: 0.96 }}
                className={`flex items-center justify-center rounded-full border border-background/70 text-background ${
                  variant === "theater" ? "h-24 w-24" : "h-16 w-16"
                }`}
              >
                <Play className={variant === "theater" ? "ml-1 h-7 w-7" : "ml-0.5 h-5 w-5"} fill="currentColor" />
              </motion.span>
            </button>
          ) : null}

          {/* Control bar */}
          {started ? (
            <div
              className={`absolute inset-x-0 bottom-0 flex items-center gap-4 bg-gradient-to-t from-charcoal/80 to-transparent px-4 py-3 text-background transition-opacity duration-300 ${
                variant === "theater"
                  ? "opacity-100"
                  : "opacity-0 group-hover:opacity-100 group-focus-within:opacity-100"
              }`}
            >
              <button
                type="button"
                onClick={togglePlay}
                aria-label={playing ? "Pause" : "Play"}
                className="shrink-0"
              >
                {playing ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
              </button>

              <span className="label-xs w-9 shrink-0 text-background/70">
                {formatTime(current)}
              </span>

              <input
                type="range"
                min={0}
                max={1}
                step={0.001}
                value={Number.isFinite(progress) ? progress : 0}
                onChange={handleScrub}
                aria-label={`Seek ${title}`}
                className="h-1 flex-1 cursor-pointer accent-[var(--bronze)]"
              />

              <span className="label-xs w-9 shrink-0 text-background/70">
                {formatTime(duration)}
              </span>

              <button type="button" onClick={toggleMute} aria-label={muted ? "Unmute" : "Mute"} className="shrink-0">
                {muted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4" />}
              </button>

              <button type="button" onClick={toggleFullscreen} aria-label="Fullscreen" className="shrink-0">
                <Maximize className="h-4 w-4" />
              </button>
            </div>
          ) : null}
        </>
      )}
    </div>
  );
}
