import { FilmPlayer } from "./FilmPlayer";
import { Reveal } from "@/components/site/Reveal";

interface CinematicShowreelProps {
  title: string;
  poster: string;
  video?: string;
  duration: string;
}

/**
 * Demonstrate filmmaking style (spec §38). Exactly one large video, never
 * a grid (spec §18). Ambient autoplay is muted-only, pauses outside the
 * viewport, and is skipped entirely under prefers-reduced-motion — all
 * handled inside FilmPlayer (spec §20, §47).
 */
export function CinematicShowreel({ title, poster, video, duration }: CinematicShowreelProps) {
  return (
    <section className="bg-charcoal py-24 text-background md:py-36">
      <div className="shell">
        <Reveal>
          <p className="label-xs text-bronze">Cinematic showreel</p>
          <div className="mt-4 flex flex-wrap items-end justify-between gap-4">
            <h2 className="font-display text-4xl leading-[0.95] md:text-7xl">{title}</h2>
            <span className="label-xs text-background/50">{duration}</span>
          </div>
        </Reveal>

        <Reveal delay={0.1} className="mt-14">
          <FilmPlayer
            poster={poster}
            video={video}
            title={title}
            variant="inline"
            ambientAutoplay
            className="aspect-video w-full"
          />
        </Reveal>
      </div>
    </section>
  );
}
