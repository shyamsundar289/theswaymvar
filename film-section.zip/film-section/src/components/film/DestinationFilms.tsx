import type { Film } from "@/types/film";
import { DestinationFilm } from "./DestinationFilm";
import { Reveal } from "@/components/site/Reveal";

interface DestinationFilmsProps {
  films: Film[];
}

/**
 * Experience & reach (spec §38). Large alternating blocks only — this is
 * the second and last place (after Film Stories) an editorial alternating
 * layout is used, kept distinct from the Collection grid above it.
 */
export function DestinationFilms({ films }: DestinationFilmsProps) {
  if (films.length === 0) return null;

  return (
    <section className="shell section-y-lg">
      <Reveal>
        <p className="label-xs text-bronze">Destination films</p>
        <h2 className="font-display mt-4 text-4xl leading-[0.95] md:text-6xl">
          Stories from extraordinary places.
        </h2>
      </Reveal>

      <div className="mt-14 divide-y divide-border/60">
        {films.map((film, index) => (
          <DestinationFilm key={film.id} film={film} reverse={index % 2 === 1} />
        ))}
      </div>
    </section>
  );
}
