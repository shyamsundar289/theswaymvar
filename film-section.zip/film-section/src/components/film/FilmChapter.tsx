import type { FilmChapter as FilmChapterType } from "@/types/film";
import { FilmPlayer } from "./FilmPlayer";
import { Reveal } from "@/components/site/Reveal";

interface FilmChapterProps {
  chapter: FilmChapterType;
  reverse?: boolean;
}

/**
 * Editorial alternating row (spec §16). Video occupies ~60% of the row on
 * desktop, text the remainder; on mobile everything stacks (video, then
 * text) regardless of `reverse`.
 */
export function FilmChapter({ chapter, reverse = false }: FilmChapterProps) {
  // Plain flex + order utilities rather than a dir:rtl flip — keeps DOM
  // reading order and bidi text handling untouched for screen readers,
  // only the visual position moves (spec §32).
  return (
    <Reveal>
      <div className="flex flex-col gap-8 py-10 md:flex-row md:items-center md:gap-14 md:py-14">
        <div className={`md:w-[62%] ${reverse ? "md:order-2" : "md:order-1"}`}>
          <FilmPlayer
            poster={chapter.poster}
            video={chapter.video}
            title={chapter.title}
            variant="inline"
            className="aspect-[16/10] w-full"
          />
        </div>

        <div
          className={`md:w-[38%] ${reverse ? "md:order-1 md:text-right" : "md:order-2"}`}
        >
          <span className="label-xs text-bronze">{chapter.number}</span>
          <h3 className="font-display mt-3 text-3xl md:text-5xl">{chapter.title}</h3>
          <p
            className={`mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground md:text-base ${
              reverse ? "md:ml-auto" : ""
            }`}
          >
            {chapter.description}
          </p>
          {chapter.duration ? (
            <p className="label-xs mt-4 text-muted-foreground">{chapter.duration}</p>
          ) : null}
        </div>
      </div>
    </Reveal>
  );
}
