import { useEffect, useRef, useState } from "react";
import { useInView } from "@/hooks/use-in-view";
import { useReducedMotion } from "@/hooks/use-reduced-motion";
import { isMissingAsset } from "@/types/film";

interface LazyVideoProps {
  poster: string;
  video?: string;
  alt: string;
  className?: string;
  /** Silent looping preview once the element is in view + hovered (desktop only) */
  hoverPreview?: boolean;
}

/**
 * Poster-first, no-controls media block for browsing surfaces.
 * - Never downloads the video until the element is within `rootMargin` of
 *   the viewport (spec §27).
 * - Only ever plays muted, and only as a hover preview on non-touch
 *   pointers, never on load and never with sound (spec §17, §37).
 * - Falls back to a quiet placeholder frame if the poster is missing or
 *   fails to load, so a missing asset never breaks the grid (spec §45).
 */
export function LazyVideo({ poster, video, alt, className, hoverPreview = false }: LazyVideoProps) {
  const [containerRef, inView] = useInView<HTMLDivElement>({ rootMargin: "300px 0px" });
  const videoRef = useRef<HTMLVideoElement>(null);
  const [hovered, setHovered] = useState(false);
  const [posterFailed, setPosterFailed] = useState(false);
  const prefersReducedMotion = useReducedMotion();

  const canPreview =
    hoverPreview && !isMissingAsset(video) && !prefersReducedMotion && inView;

  useEffect(() => {
    const el = videoRef.current;
    if (!el || !canPreview) return;

    if (hovered) {
      el.play().catch(() => {
        /* autoplay can be legitimately rejected — poster stays visible, silently ignore */
      });
    } else {
      el.pause();
      el.currentTime = 0;
    }
  }, [hovered, canPreview]);

  const showPoster = isMissingAsset(poster) || posterFailed;

  return (
    <div
      ref={containerRef}
      className={`relative overflow-hidden bg-charcoal ${className ?? ""}`}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      {showPoster ? (
        <div
          role="img"
          aria-label={alt}
          className="flex h-full w-full items-center justify-center bg-gradient-to-br from-charcoal to-[#231d18] text-background/25"
        >
          <span className="label-xs">theswaymvar</span>
        </div>
      ) : (
        <img
          src={poster}
          alt={alt}
          loading="lazy"
          decoding="async"
          onError={() => setPosterFailed(true)}
          className={`h-full w-full object-cover transition-opacity duration-500 ${
            canPreview && hovered ? "opacity-0" : "opacity-100"
          }`}
        />
      )}

      {canPreview ? (
        <video
          ref={videoRef}
          src={inView ? video : undefined}
          muted
          loop
          playsInline
          preload="none"
          aria-hidden="true"
          tabIndex={-1}
          className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-500 ${
            hovered ? "opacity-100" : "opacity-0"
          }`}
        />
      ) : null}
    </div>
  );
}
