import type { ReactNode } from "react";
import { ArrowUpRight } from "lucide-react";

interface WhatsAppButtonProps {
  message: string;
  children: ReactNode;
  className?: string;
}

/**
 * Minimal WhatsApp deep-link CTA. Replace WHATSAPP_NUMBER with the studio's
 * real number (E.164 format, digits only) before shipping.
 */
const WHATSAPP_NUMBER = "910000000000";

export function WhatsAppButton({ message, children, className }: WhatsAppButtonProps) {
  const href = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={href}
      target="_blank"
      rel="noopener noreferrer"
      className={`group inline-flex items-center gap-3 border border-border px-8 py-4 transition-colors hover:border-bronze hover:text-bronze ${
        className ?? ""
      }`}
    >
      <span className="label-xs">{children}</span>
      <ArrowUpRight className="h-4 w-4 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
    </a>
  );
}
