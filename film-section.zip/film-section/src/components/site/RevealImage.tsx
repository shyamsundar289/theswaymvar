import { motion, useReducedMotion } from "framer-motion";
import { useState } from "react";

interface RevealImageProps {
  src: string;
  alt: string;
  className?: string;
  /** Renders an inline <video> element instead of <img> when true */
  as?: "img" | "video";
}

/**
 * Scroll-revealed media block: fades in and settles from a slight scale,
 * with a graceful failure state so a missing poster never collapses the
 * layout (spec §45).
 */
export function RevealImage({ src, alt, className, as = "img" }: RevealImageProps) {
  const prefersReducedMotion = useReducedMotion();
  const [failed, setFailed] = useState(false);
  const hasSrc = Boolean(src) && !failed;

  return (
    <motion.div
      className={`relative overflow-hidden bg-charcoal ${className ?? ""}`}
      initial={{ opacity: 0, scale: prefersReducedMotion ? 1 : 1.04 }}
      whileInView={{ opacity: 1, scale: 1 }}
      viewport={{ once: true, margin: "-10% 0px -10% 0px" }}
      transition={{ duration: prefersReducedMotion ? 0.2 : 0.9, ease: [0.16, 1, 0.3, 1] }}
    >
      {hasSrc ? (
        as === "video" ? (
          <video
            src={src}
            aria-label={alt}
            className="h-full w-full object-cover"
            muted
            playsInline
            onError={() => setFailed(true)}
          />
        ) : (
          <img
            src={src}
            alt={alt}
            loading="lazy"
            className="h-full w-full object-cover"
            onError={() => setFailed(true)}
          />
        )
      ) : (
        <div
          role="img"
          aria-label={alt}
          className="flex h-full w-full items-center justify-center bg-gradient-to-br from-charcoal to-[#231d18] text-background/30"
        >
          <span className="label-xs">theswaymvar</span>
        </div>
      )}
    </motion.div>
  );
}
