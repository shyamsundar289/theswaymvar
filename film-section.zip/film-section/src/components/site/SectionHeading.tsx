import { Reveal } from "./Reveal";

interface SectionHeadingProps {
  eyebrow: string;
  title: string;
  /** Optional right-aligned or supporting line under the title */
  description?: string;
  className?: string;
  align?: "left" | "center";
}

export function SectionHeading({
  eyebrow,
  title,
  description,
  className,
  align = "left",
}: SectionHeadingProps) {
  return (
    <Reveal className={className}>
      <div className={align === "center" ? "text-center" : undefined}>
        <p className="label-xs text-bronze">{eyebrow}</p>
        <h2 className="font-display mt-4 text-4xl leading-[0.95] md:text-6xl">
          {title}
        </h2>
        {description ? (
          <p
            className={`mt-4 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base ${
              align === "center" ? "mx-auto" : ""
            }`}
          >
            {description}
          </p>
        ) : null}
      </div>
    </Reveal>
  );
}
