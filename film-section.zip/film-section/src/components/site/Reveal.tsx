import { motion, useReducedMotion, type HTMLMotionProps } from "framer-motion";
import type { ReactNode } from "react";

interface RevealProps extends Omit<HTMLMotionProps<"div">, "children"> {
  children: ReactNode;
  /** Stagger offset in seconds, e.g. index * 0.08 */
  delay?: number;
  className?: string;
  /** Vertical travel distance in px before settling */
  distance?: number;
}

/**
 * Generic fade-up scroll reveal. Fires once per element (viewport margin
 * keeps it from re-triggering while scrolling up and down past the same
 * section — spec §46), and collapses to a plain opacity fade when the user
 * prefers reduced motion (spec §47).
 */
export function Reveal({
  children,
  delay = 0,
  className,
  distance = 28,
  ...rest
}: RevealProps) {
  const prefersReducedMotion = useReducedMotion();

  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: prefersReducedMotion ? 0 : distance }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-10% 0px -10% 0px" }}
      transition={{
        duration: prefersReducedMotion ? 0.2 : 0.7,
        delay: prefersReducedMotion ? 0 : delay,
        ease: [0.16, 1, 0.3, 1],
      }}
      {...rest}
    >
      {children}
    </motion.div>
  );
}
