/**
 * FILM DATA MODEL
 * ----------------------------------------------------------------------------
 * One shape powers Featured Film, Film Collection, Film Stories, Destination
 * Films, and the Film Detail route. Never fork this type per-component —
 * every section reads a view of the same `Film[]` array in `src/data/films.ts`.
 */

export type FilmCategory = "wedding" | "pre-wedding" | "destination";

export const FILM_CATEGORIES: { value: FilmCategory | "all"; label: string }[] = [
  { value: "all", label: "All" },
  { value: "wedding", label: "Weddings" },
  { value: "pre-wedding", label: "Pre-Wedding" },
  { value: "destination", label: "Destination" },
];

export interface FilmChapter {
  /** Display order, e.g. "01" */
  number: string;
  title: string;
  description: string;
  /** Poster frame — always required, video is optional until the asset exists */
  poster: string;
  video?: string;
  /** mm:ss */
  duration?: string;
}

export interface Film {
  /** Stable identifier, also used as the route slug (/films/:slug) */
  id: string;
  slug: string;
  title: string;
  /** Optional — some films (showreel, teasers) have no named couple */
  couple?: string;
  location: string;
  region?: string;
  year: number;
  category: FilmCategory;
  /** mm:ss */
  duration: string;
  poster: string;
  /** Optional until the real asset is uploaded — components must degrade gracefully */
  video?: string;
  description: string;
  /** Exactly one film in the data set should be `featured: true` */
  featured?: boolean;
  /** Marks a film for the Destination Films section, independent of `category` */
  destination?: boolean;
  /** Present only on the film(s) used in the Film Stories section */
  chapters?: FilmChapter[];
}

export function isMissingAsset(src?: string): boolean {
  return !src || src.trim().length === 0;
}
