/**
 * IMAGE REGISTRY — PLACEHOLDER ASSETS
 * ----------------------------------------------------------------------------
 * These paths do not resolve to real files yet. Every component that reads
 * from `images` degrades gracefully when a path 404s (see RevealImage and
 * LazyVideo's onError handling), so the page won't break before you drop
 * real files into /public/assets/films and update the paths below.
 *
 * Keep this as the ONLY place that lists poster/video paths for the film
 * page — src/data/films.ts imports from here rather than hardcoding paths.
 */
export const images = {
  films: {
    // Already referenced by the existing /film hero + manifesto sections
    reelA: "/assets/films/reel-a.jpg",
    reelB: "/assets/films/reel-b.jpg",
    highlightA: "/assets/films/highlight-a.jpg",

    // Featured film
    royalWeddingPoster: "/assets/films/royal-wedding/poster.jpg",
    royalWeddingVideo: "", // TODO: add real video source

    // Collection
    palaceWeddingPoster: "/assets/films/palace-wedding/poster.jpg",
    lakePalacePoster: "/assets/films/lake-palace/poster.jpg",
    haveliPreWedPoster: "/assets/films/haveli-pre-wedding/poster.jpg",
    fortWeddingPoster: "/assets/films/fort-wedding/poster.jpg",
    desertPreWedPoster: "/assets/films/desert-pre-wedding/poster.jpg",
    beachDestinationPoster: "/assets/films/beach-destination/poster.jpg",
    gardenWeddingPoster: "/assets/films/garden-wedding/poster.jpg",
    hillPreWedPoster: "/assets/films/hill-pre-wedding/poster.jpg",

    // Film Stories chapters (Royal Wedding)
    chapterArrival: "/assets/films/royal-wedding/chapter-arrival.jpg",
    chapterBride: "/assets/films/royal-wedding/chapter-bride.jpg",
    chapterGroom: "/assets/films/royal-wedding/chapter-groom.jpg",
    chapterCeremony: "/assets/films/royal-wedding/chapter-ceremony.jpg",
    chapterCelebration: "/assets/films/royal-wedding/chapter-celebration.jpg",
    chapterNight: "/assets/films/royal-wedding/chapter-night.jpg",

    // Showreel
    showreelPoster: "/assets/films/showreel/poster.jpg",
    showreelVideo: "", // TODO: add real ~60s cut

    // Destination Films
    jaipurPoster: "/assets/films/destinations/jaipur.jpg",
    udaipurPoster: "/assets/films/destinations/udaipur.jpg",
    jodhpurPoster: "/assets/films/destinations/jodhpur.jpg",
  },
} as const;
