import { images } from "./images";
import type { Film } from "@/types/film";

/**
 * FILM DATA — SINGLE SOURCE OF TRUTH
 * ----------------------------------------------------------------------------
 * Every section on /film reads from this array. Do not duplicate film
 * metadata inside individual components (spec §25, §44).
 *
 * `video` is left empty ("") on entries where no real cut exists yet —
 * every player component (LazyVideo / FilmPlayer) treats an empty video
 * as "poster only" and shows a quiet "Film coming soon" state rather than
 * a broken player (spec §26, §45).
 *
 * Exactly one film is marked `featured: true` — that's the one the
 * Featured Film section renders. Exactly one carries `chapters` — that's
 * the one Film Stories breaks down. Three carry `destination: true` — those
 * power the Destination Films section, independent of `category`.
 */
export const films: Film[] = [
  {
    id: "royal-wedding-jaipur",
    slug: "the-royal-wedding",
    title: "The Royal Wedding",
    couple: "Ananya & Vikram",
    location: "Jaipur",
    region: "Rajasthan · India",
    year: 2026,
    category: "wedding",
    duration: "02:18",
    poster: images.films.royalWeddingPoster,
    video: images.films.royalWeddingVideo,
    description:
      "Three days inside a City Palace wedding — the processions, the vows at dusk, and the quiet hour before the city woke up to celebrate with them.",
    featured: true,
    destination: true,
    chapters: [
      {
        number: "01",
        title: "Arrival",
        description: "The anticipation before the celebration begins.",
        poster: images.films.chapterArrival,
        video: "",
        duration: "0:42",
      },
      {
        number: "02",
        title: "The Bride",
        description: "Quiet moments before she enters the celebration.",
        poster: images.films.chapterBride,
        video: "",
        duration: "1:05",
      },
      {
        number: "03",
        title: "The Groom",
        description: "The energy, emotion and anticipation before the ceremony.",
        poster: images.films.chapterGroom,
        video: "",
        duration: "0:38",
      },
      {
        number: "04",
        title: "The Ceremony",
        description: "Tradition, family and promises.",
        poster: images.films.chapterCeremony,
        video: "",
        duration: "1:24",
      },
      {
        number: "05",
        title: "The Celebration",
        description: "Music, movement and unforgettable moments.",
        poster: images.films.chapterCelebration,
        video: "",
        duration: "0:57",
      },
      {
        number: "06",
        title: "The Night",
        description: "The final moments of an unforgettable celebration.",
        poster: images.films.chapterNight,
        video: "",
        duration: "0:49",
      },
    ],
  },
  {
    id: "palace-wedding-udaipur",
    slug: "the-palace-wedding",
    title: "The Palace Wedding",
    couple: "Ananya & Rahul",
    location: "Udaipur",
    region: "Rajasthan · India",
    year: 2026,
    category: "wedding",
    duration: "03:12",
    poster: images.films.palaceWeddingPoster,
    video: "",
    description:
      "A lakeside wedding held across two palace courtyards, cut for the moments between the ceremony rather than the ceremony itself.",
    destination: true,
  },
  {
    id: "lake-palace-udaipur",
    slug: "lake-palace-vows",
    title: "Lake Palace Vows",
    couple: "Meera & Arjun",
    location: "Udaipur",
    region: "Rajasthan · India",
    year: 2025,
    category: "wedding",
    duration: "04:05",
    poster: images.films.lakePalacePoster,
    video: "",
    description:
      "Vows exchanged at sunset on the water, with the whole city catching the light behind them.",
  },
  {
    id: "haveli-pre-wedding",
    slug: "haveli-mornings",
    title: "Haveli Mornings",
    couple: "Simran & Kabir",
    location: "Jodhpur",
    region: "Rajasthan · India",
    year: 2026,
    category: "pre-wedding",
    duration: "01:47",
    poster: images.films.haveliPreWedPoster,
    video: "",
    description:
      "An early-morning shoot through the blue lanes of the old city, before Jodhpur properly woke up.",
    destination: true,
  },
  {
    id: "fort-wedding-jodhpur",
    slug: "the-fort-wedding",
    title: "The Fort Wedding",
    couple: "Naina & Dev",
    location: "Jodhpur",
    region: "Rajasthan · India",
    year: 2025,
    category: "wedding",
    duration: "03:41",
    poster: images.films.fortWeddingPoster,
    video: "",
    description:
      "Mehrangarh's ramparts as a backdrop for a three-generation family wedding, filmed low and wide.",
  },
  {
    id: "desert-pre-wedding",
    slug: "dunes-before-dawn",
    title: "Dunes Before Dawn",
    couple: "Priya & Aditya",
    location: "Jaisalmer",
    region: "Rajasthan · India",
    year: 2026,
    category: "pre-wedding",
    duration: "02:02",
    poster: images.films.desertPreWedPoster,
    video: "",
    description:
      "A single sunrise, a stretch of dunes, and a couple who asked for almost no direction at all.",
  },
  {
    id: "beach-destination-goa",
    slug: "goa-golden-hour",
    title: "Goa, Golden Hour",
    couple: "Isha & Karan",
    location: "Goa",
    region: "India",
    year: 2025,
    category: "destination",
    duration: "03:28",
    poster: images.films.beachDestinationPoster,
    video: "",
    description:
      "A barefoot ceremony on the sand, then a reception that ran well past what anyone had planned.",
  },
  {
    id: "garden-wedding-delhi",
    slug: "the-garden-wedding",
    title: "The Garden Wedding",
    couple: "Ritika & Sameer",
    location: "New Delhi",
    region: "India",
    year: 2025,
    category: "wedding",
    duration: "02:54",
    poster: images.films.gardenWeddingPoster,
    video: "",
    description:
      "An intimate 80-guest wedding under a century-old banyan tree, shot almost entirely handheld.",
  },
  {
    id: "hill-pre-wedding-shimla",
    slug: "above-the-clouds",
    title: "Above the Clouds",
    couple: "Tara & Yash",
    location: "Shimla",
    region: "Himachal Pradesh · India",
    year: 2026,
    category: "pre-wedding",
    duration: "01:33",
    poster: images.films.hillPreWedPoster,
    video: "",
    description: "Fog rolling through pine forests while two people who clearly like each other pretended not to notice the camera.",
  },
];

/** Exactly one entry should satisfy this — the Featured Film section reads it directly. */
export const featuredFilm: Film = films.find((film) => film.featured) ?? films[0];

/** The story-driven wedding used by the Film Stories section. */
export const storyFilm: Film | undefined = films.find(
  (film) => film.chapters && film.chapters.length > 0,
);

/** Films flagged for the Destination Films section, independent of category. */
export const destinationFilms: Film[] = films.filter((film) => film.destination);

/** The cinematic showreel is not a wedding in the collection — kept separate. */
export const showreel = {
  title: "The Art of Motion",
  poster: images.films.showreelPoster,
  video: images.films.showreelVideo,
  duration: "1:02",
};

export function getFilmBySlug(slug: string): Film | undefined {
  return films.find((film) => film.slug === slug);
}
