/**
 * Central GSAP setup.
 * ----------------------------------------------------------------------------
 * Import `gsap` and `ScrollTrigger` from THIS file everywhere, never straight
 * from "gsap" — it guarantees the plugin is registered exactly once and
 * guards against SSR (no `window` at module-eval time on the server).
 *
 * npm install gsap
 */
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";

if (typeof window !== "undefined") {
  gsap.registerPlugin(ScrollTrigger);
  // Keep pinned/scrubbed animations lined up with lazy-loaded media and
  // fonts swapping in — cheap to call, avoids "stuck" trigger positions
  // after fast scrolling (spec §46).
  gsap.ticker.lagSmoothing(0);
}

export { gsap, ScrollTrigger };
