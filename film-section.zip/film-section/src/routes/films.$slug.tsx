import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowLeft } from "lucide-react";

import { getFilmBySlug } from "@/data/films";
import { FilmPlayer } from "@/components/film/FilmPlayer";
import { Reveal } from "@/components/site/Reveal";
import { WhatsAppButton } from "@/components/site/CTA";

export const Route = createFileRoute("/films/$slug")({
  loader: ({ params }) => getFilmBySlug(params.slug) ?? null,

  head: ({ loaderData }) => ({
    meta: [
      {
        title: loaderData
          ? `${loaderData.title} — theswaymvar films`
          : "Film not found — theswaymvar",
      },
      {
        name: "description",
        content: loaderData?.description ?? "This film could not be found.",
      },
      { property: "og:type", content: "video.other" },
      ...(loaderData ? [{ property: "og:image", content: loaderData.poster }] : []),
    ],
  }),

  component: FilmDetailPage,
  notFoundComponent: FilmNotFound,
});

const CATEGORY_LABEL: Record<string, string> = {
  wedding: "Wedding film",
  "pre-wedding": "Pre-wedding film",
  destination: "Destination film",
};

function FilmNotFound() {
  return (
    <div className="shell flex min-h-[60vh] flex-col items-center justify-center py-24 text-center">
      <p className="label-xs text-bronze">Film not found</p>
      <h1 className="font-display mt-4 text-4xl md:text-6xl">
        We couldn&apos;t find that film.
      </h1>
      <Link
        to="/film"
        className="story-link label-xs mt-8 inline-flex items-center gap-2"
      >
        <ArrowLeft className="h-3.5 w-3.5" />
        Back to films
      </Link>
    </div>
  );
}

function FilmDetailPage() {
  const film = Route.useLoaderData();

  if (!film) return <FilmNotFound />;

  const metaLine = [film.location, film.region, film.year].filter(Boolean).join(" · ");

  return (
    <article className="pb-24">
      <div className="shell pt-8">
        <Link
          to="/film"
          className="story-link label-xs inline-flex items-center gap-2 text-muted-foreground"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          Back to films
        </Link>
      </div>

      <div className="shell mt-8">
        <Reveal>
          <FilmPlayer
            poster={film.poster}
            video={film.video}
            title={film.title}
            variant="theater"
            className="aspect-video w-full"
          />
        </Reveal>
      </div>

      <div className="shell mt-10 grid gap-10 md:grid-cols-12">
        <Reveal className="md:col-span-8">
          <p className="label-xs text-bronze">{CATEGORY_LABEL[film.category] ?? film.category}</p>
          <h1 className="font-display mt-4 text-4xl leading-[0.95] md:text-6xl">
            {film.title}
          </h1>
          {film.couple ? (
            <p className="mt-3 text-base text-muted-foreground">{film.couple}</p>
          ) : null}
          <p className="label-xs mt-4 text-muted-foreground">
            {metaLine} · {film.duration}
          </p>
          <p className="mt-8 max-w-2xl text-sm leading-relaxed text-muted-foreground md:text-base">
            {film.description}
          </p>
        </Reveal>

        <Reveal delay={0.1} className="md:col-span-4 md:border-l md:border-border md:pl-10">
          <p className="label-xs text-muted-foreground">Planning something similar?</p>
          <div className="mt-5">
            <WhatsAppButton message={`Hello theswaymvar — I loved "${film.title}" and would like to enquire about wedding films.`}>
              Enquire on WhatsApp
            </WhatsAppButton>
          </div>
        </Reveal>
      </div>
    </article>
  );
}
