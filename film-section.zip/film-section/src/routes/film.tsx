import { createFileRoute } from "@tanstack/react-router";

import { films, featuredFilm, storyFilm, destinationFilms, showreel } from "@/data/films";

import { FilmHero } from "@/components/film/FilmHero";
import { FeaturedFilm } from "@/components/film/FeaturedFilm";
import { FilmCollection } from "@/components/film/FilmCollection";
import { FilmStories } from "@/components/film/FilmStories";
import { CinematicShowreel } from "@/components/film/CinematicShowreel";
import { DestinationFilms } from "@/components/film/DestinationFilms";
import { Reveal } from "@/components/site/Reveal";
import { WhatsAppButton } from "@/components/site/CTA";

export const Route = createFileRoute("/film")({
  head: () => ({
    meta: [
      { title: "Film — Wedding Films Cut for Feeling | theswaymvar" },
      {
        name: "description",
        content:
          "Story-led Indian wedding films with live sound, honest moments and edits made to remember the day rather than the reel.",
      },
      { property: "og:title", content: "Film — Wedding Films Cut for Feeling | theswaymvar" },
      {
        property: "og:description",
        content: "Wedding films with live sound, made for memory rather than the reel.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
      { property: "og:image", content: featuredFilm.poster },
      { name: "twitter:image", content: featuredFilm.poster },
    ],
  }),

  component: FilmPage,
});

function FinalCTA() {
  return (
    <section className="shell section-y-lg text-center">
      <Reveal>
        <p className="label-xs text-bronze">Start with the dates</p>

        <h2 className="font-display mx-auto mt-6 max-w-4xl text-5xl leading-[0.95] md:text-8xl">
          Your story deserves
          <br />
          to be remembered.
        </h2>

        <p className="mx-auto mt-7 max-w-xl text-sm leading-relaxed text-muted-foreground md:text-base">
          Tell us where you&apos;re getting married and what you want to
          remember. We&apos;ll take it from there.
        </p>

        <div className="mt-10 flex justify-center">
          <WhatsAppButton message="Hello theswaymvar — we'd like to enquire about wedding films.">
            Start a conversation
          </WhatsAppButton>
        </div>
      </Reveal>
    </section>
  );
}

function FilmPage() {
  return (
    <>
      <FilmHero />

      <FeaturedFilm film={featuredFilm} />

      <FilmCollection films={films} />

      {storyFilm ? <FilmStories film={storyFilm} /> : null}

      <CinematicShowreel
        title={showreel.title}
        poster={showreel.poster}
        video={showreel.video}
        duration={showreel.duration}
      />

      <DestinationFilms films={destinationFilms} />

      <FinalCTA />
    </>
  );
}
